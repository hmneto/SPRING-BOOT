package br.com.app.enums;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_USER
}
